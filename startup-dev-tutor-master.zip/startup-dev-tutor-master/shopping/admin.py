from shopping.models import Product
from django.contrib import admin

admin.site.register(Product)